package com.example.customspinnerapp;

public class customList {
    private String spinnerText;
    private int spinnerImage;

    public customList(String spinnerText, int spinnerImage) {
        this.spinnerText = spinnerText;
        this.spinnerImage = spinnerImage;
    }

    public String getSpinnerText() {
        return spinnerText;
    }

    public int getSpinnerImage() {
        return spinnerImage;
    }
}
